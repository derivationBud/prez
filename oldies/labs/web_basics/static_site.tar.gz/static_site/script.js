var splash = function(){

    var msg       = document.createElement("p")
    msg.style     = "color:orange;font-size:1.6em;text-align:center;"
    msg.innerHTML = "-> SNOWBALL <-"

    var dst = document.getElementById("content")
    dst.appendChild(msg)

}
